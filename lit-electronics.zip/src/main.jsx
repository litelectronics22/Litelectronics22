import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import ElectronicsStore from './ElectronicsStore'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ElectronicsStore />
  </React.StrictMode>
)
