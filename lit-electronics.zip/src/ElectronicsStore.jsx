import React, { useState } from "react";

const products = [
  {
    id: 1,
    name: "Wireless Headphones",
    price: 99.99,
    image: "https://via.placeholder.com/150"
  },
  {
    id: 2,
    name: "Smart Watch",
    price: 149.99,
    image: "https://via.placeholder.com/150"
  },
  {
    id: 3,
    name: "Bluetooth Speaker",
    price: 79.99,
    image: "https://via.placeholder.com/150"
  }
];

export default function ElectronicsStore() {
  const [cart, setCart] = useState([]);

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  const total = cart.reduce((sum, item) => sum + item.price, 0).toFixed(2);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <h1 className="text-3xl font-bold mb-6 text-center">Lit Electronics</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {products.map((product) => (
          <div key={product.id} className="rounded-2xl shadow-md bg-white p-4">
            <img
              src={product.image}
              alt={product.name}
              className="w-32 h-32 object-cover mx-auto mb-4"
            />
            <h2 className="text-xl font-semibold text-center">{product.name}</h2>
            <p className="text-gray-700 text-center mb-2">${product.price.toFixed(2)}</p>
            <button
              onClick={() => addToCart(product)}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg block mx-auto"
            >
              Add to Cart
            </button>
          </div>
        ))}
      </div>

      {cart.length > 0 && (
        <div className="mt-8 p-6 bg-white rounded-2xl shadow-lg max-w-xl mx-auto">
          <h2 className="text-2xl font-semibold mb-4">Your Cart</h2>
          <ul>
            {cart.map((item, index) => (
              <li key={index} className="flex justify-between border-b py-2">
                <span>{item.name}</span>
                <span>${item.price.toFixed(2)}</span>
              </li>
            ))}
          </ul>
          <div className="flex justify-between mt-4 font-bold text-lg">
            <span>Total:</span>
            <span>${total}</span>
          </div>
          <button className="mt-4 w-full bg-green-600 text-white py-2 rounded-lg">
            Checkout (Payment Placeholder)
          </button>
        </div>
      )}
    </div>
  );
}
